package com.sellersdatabase.login;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.sellersdatabase.database.Seller;
import com.sellersdatabase.database.SellerDAO;

@Service
public class LoginService {
	public boolean isInteger(String s) {
	    try { 
	    	double d = Double.parseDouble(s);
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}
	
	public boolean confirm(String p1, String p2)
	{
		if(p1.equals(p2))return true;
		else return false;
	}
	
	public boolean validNamePass(String n, String p)
	{
		if(n.isEmpty() || n.equals(""))return false;
		if(p.isEmpty() || p.equals(""))return false;
		return true;
	}
	
	public Seller validateUser(String user, String password) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
		
		Seller customer = new Seller(user.toUpperCase(),password);
		Seller logged= sellerDAO.select(customer);
		
		return logged;
	}

}