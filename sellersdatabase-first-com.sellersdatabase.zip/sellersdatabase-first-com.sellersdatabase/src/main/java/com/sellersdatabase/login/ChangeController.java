package com.sellersdatabase.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sellersdatabase.database.Seller;
import com.sellersdatabase.database.SellerDAO;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Controller
public class ChangeController {
	
	@Autowired
	LoginService loginservice;
	
	@RequestMapping(value="/change",method=RequestMethod.GET)
	
	public String showchange()
	{
		return "change";
	}
	
	@RequestMapping(value="/change",method=RequestMethod.POST)

	public String leavechange(HttpServletRequest request,ModelMap model)
	{
		String name = request.getParameter("name");
		String password=request.getParameter("password");
		String production= request.getParameter("production");
		String tk= request.getParameter("tk");
		String customername=request.getParameter("customername");
		
		String name_new=request.getParameter("name_new");
		String password_new=request.getParameter("password_new");
		
		
		if (request.getParameter("profile") != null) {
			
			model.put("name", name);
			model.put("production",production);
			model.put("tk",tk);
			model.put("customername", customername);
			model.put("password", password);
			
			return "profile";
		
		}
		
		else if(request.getParameter("change") != null)
		{
			model.put("name", name);
			model.put("production",production);
			model.put("tk",tk);
			model.put("customername", customername);
			model.put("password", password);
			
			ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
			SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
			
			Seller existing =loginservice.validateUser(name_new, password_new);
			
			boolean validnamepass=loginservice.validNamePass(name_new, password_new);
			
			if(!validnamepass)
			{
				model.put("error","Username/Password field can not be empty...");
				return "change";
			}
			
			if(existing!=null)
			{
				model.put("error","Username/Password combination is taken, Please choose another one");
				return "change";
			}
			
			Seller old_man1=loginservice.validateUser(name, password);
			sellerDAO.update(old_man1,"NAME",name_new);
			
			Seller old_man2=loginservice.validateUser(name_new, password);
			sellerDAO.update(old_man2,"PASSWORD",password_new);
			
			model.put("success","Account settings are changed successfully...");
			
			model.put("name", name_new);
			model.put("production",old_man2.getProduction());
			model.put("tk",old_man2.getTk());
			model.put("customername", old_man2.getCustomername());
			model.put("password", password_new);
			
			return "profile";
		}
		return null;
	}

}
