package com.sellersdatabase.login;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sellersdatabase.database.Seller;
import com.sellersdatabase.database.SellerDAO;


@Controller
public class LoginController {
	
	@Autowired
	LoginService loginservice;
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	
	public String showlogin()
	{
		return "login";
	}
	
@RequestMapping(value="/login",method=RequestMethod.POST)
	
	public String leavelogin(ModelMap model,HttpServletRequest request)
	{
	
		if (request.getParameter("login") != null)
		{
			String name = request.getParameter("name");
			String password=request.getParameter("password");
			
			Seller logged=loginservice.validateUser(name, password);
			
			
			if(logged==null)
			{
				model.put("error", "invalid username/password");
				return "login";
			}
			
			model.put("name", logged.getName());
			model.put("production",logged.getProduction());
			model.put("tk",logged.getTk());
			model.put("customername", logged.getCustomername());
			model.put("password", logged.getPassword());
			
			return "profile";
		}
		
		else if (request.getParameter("signup") != null)
		{
			return "signup";
		}
		return null;
	}

	
	
}
