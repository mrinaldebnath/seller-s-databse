package com.sellersdatabase.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sellersdatabase.database.Seller;
import com.sellersdatabase.database.SellerDAO;

@Controller
public class ShowController extends HttpServlet {
	
	
	@Autowired
	LoginService loginservice;
	
@RequestMapping(value="/show",method=RequestMethod.GET)
	
	public String showprofile()
	{
		return "profile";
	}
 	
	@RequestMapping(value="/show",method=RequestMethod.POST)
	
	public String leaverofile(HttpServletRequest request,ModelMap model)
	{
		if (request.getParameter("signout") != null) {
		    return "login";
		}
		else if(request.getParameter("profile") != null)
			
		{
			String name = request.getParameter("name");
			String password=request.getParameter("password");
			String production= request.getParameter("production");
			String tk= request.getParameter("tk");
			String customername=request.getParameter("customername");
			
			ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
			SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
			
			Seller customer =loginservice.validateUser(name, password);
			
			
			model.put("name", name.toUpperCase());
			model.put("production",production);
			model.put("tk",customer.getTk());
			model.put("customername", customername);
			model.put("password", password);
			
		    return "profile";
		}
		
		return null;
	}
	    
}