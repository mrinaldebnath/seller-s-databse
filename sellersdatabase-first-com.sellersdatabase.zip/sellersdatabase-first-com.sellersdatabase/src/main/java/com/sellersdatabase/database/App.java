package com.sellersdatabase.database;

import java.sql.Timestamp;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {
	
	public static void main( String[] args )
    {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("customerDAO");
		Seller logged=null;
		
		while(true)
		{
			 Scanner sc=new Scanner(System.in);
			 
			 String op=sc.next();
			 if(op.equals("reg"))
			 {
				 String name=sc.next();
				 String pass=sc.next();
				 String prod=sc.next();
				 int tk=sc.nextInt();
				 String cust=sc.next();
				 
				 Seller customer = new Seller(name,pass,prod,tk,cust);
			        sellerDAO.insert(customer);
			        
			        System.out.println("registration successful...");
			 }
			 
			 else if(op.equals("log"))
			 {
				 String name=sc.next();
				 String pass=sc.next();
				 
				 Seller customer = new Seller(name,pass);
			      logged= sellerDAO.select(customer);
			        
			      if(logged!=null)System.out.println(logged.toString());
			      else System.out.println("invalid username or password");
			        
			 }
			 
			 else if(op.equals("signout"))
			 {
				 System.out.println("signing out....");
				 logged=null;
			 }
			 else if(op.equals("update"))
			 {
				 if(logged==null)
				 {
					 System.out.println("At first, sign in");
					 continue;
				 }
				 
				 System.out.println("Which column do you want to update?");
				 
				 String column=sc.next();
				 String value=sc.next();
				 
				 sellerDAO.update(logged,column,value);
				 System.out.println("updated successfully...");
			 }
			 
			 else if(op.equals("delete"))
			 {
				 if(logged==null)
				 {
					 System.out.println("At first, sign in");
					 continue;
				 }
				 
				 sellerDAO.delete(logged);
				 System.out.println("deleted successfully...");
				 logged=null;
			 }
			 
			 else if(op.equals("show"))
			 {
				 if(logged==null)
				 {
					 System.out.println("At first, sign in");
					 continue;
				 }
				 if(logged!=null)System.out.println(logged.toString());
			 }
					 
			 else if(op.equals("quit"))break;
		}
		
		

    }
}
