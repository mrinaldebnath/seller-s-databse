package com.sellersdatabase.database;

import java.util.ArrayList;

public interface SellerDAO {
	
	public void insert(Seller seller);
	public void delete(Seller seller);
	public void update(Seller seller,String column,String value);
	
	public Seller select(Seller seller);
	
	public Seller findBySellerId(int sellId);
	public ArrayList<ArrayList<String>> selectAll();
}
