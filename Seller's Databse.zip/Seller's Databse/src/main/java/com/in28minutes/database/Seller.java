package com.in28minutes.database;

import java.sql.Timestamp;

public class Seller {
	
	int sellerId;
	String name;
	String password;
	String production;
	int tk;
	String customerName;
	
	public Seller(String name, String pass,String p,int amount,String c) {
		this.name = name;
		this.password = pass;
		this.production=p;
		this.tk=amount;
		this.customerName=c;
		
	}
	
	public Seller(String name, String pass) {
		this.name = name;
		this.password = pass;
		
	}
	
	public int sellerId() {
		return sellerId;
	}
	public void setsellerId(int Id) {
		this.sellerId = Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String p) {
		this.password = p;
	}
	
	public String getProduction() {
		return production;
	}
	public void setProduction(String p) {
		this.production = p;
	}
	
	public String getCustomername() {
		return customerName;
	}
	public void setCustomername(String p) {
		this.customerName = p;
	}
	
	public int getTk() {
		return tk;
	}
	public void setTk(int d) {
		this.tk = d;
	}

	@Override
	public String toString() {
		return "Seller [name=" + name + ", production=" + production + ", Tk=" + tk
				+ " customer = "+customerName+" ]";
	}
	
}
