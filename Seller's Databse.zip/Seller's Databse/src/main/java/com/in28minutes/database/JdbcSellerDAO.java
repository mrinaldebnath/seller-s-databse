package com.in28minutes.database;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.sql.DataSource;

public class JdbcSellerDAO<al> implements SellerDAO {
	
	
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void insert(Seller seller) {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO SELLER " +
				"(NAME, PASSWORD,PRODUCTION,TK,CUSTOMERNAME) VALUES (?, ?, ?,?,?)";
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, seller.getName().toUpperCase());
			ps.setString(2, seller.getPassword());
			ps.setString(3, seller.getProduction());
			ps.setInt(4, seller.getTk());
			ps.setString(5, seller.getCustomername());
			
			
			ps.executeUpdate();
			ps.close();

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
		

	}
	
	public void delete(Seller seller) {
		// TODO Auto-generated method stub
		
		String sql = "DELETE FROM SELLER WHERE NAME=? AND PASSWORD =?";
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, seller.getName().toUpperCase());
			ps.setString(2, seller.getPassword());
			
			
			ps.executeUpdate();
			ps.close();

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
		

	}
	
	public void update(Seller seller,String column,String value) {
		// TODO Auto-generated method stub
		String v;
		if(column.equals("NAME"))v=value.toUpperCase();
		else v=value;
		
		String sql = "UPDATE SELLER SET "+column+" = '"+v+"'  WHERE NAME= '"+seller.getName().toUpperCase()+"' AND PASSWORD = '"+seller.getPassword()+"'";
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
				
			ps.executeUpdate();
			ps.close();

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
		

	}
	
	public Seller select(Seller seller) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM SELLER WHERE NAME = ? AND PASSWORD= ?";
		Connection conn = null;

		try {	
			
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, seller.getName().toUpperCase());
			ps.setString(2, seller.getPassword());
			
			Seller logged = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				logged = new Seller(
					rs.getString("NAME"),
					rs.getString("PASSWORD"),
					rs.getString("PRODUCTION"),
					rs.getInt("TK"),
					rs.getString("CUSTOMERNAME")
					
				);
			}
			rs.close();
			ps.close();
			return logged;

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
		

	}
	
	@SuppressWarnings({ "unchecked", "unchecked" })
	public ArrayList<ArrayList<String>> selectAll()
	{
		String sql = "SELECT * FROM SELLER";
		Connection conn = null;
		ArrayList<String> al = null;
        ArrayList<al> pid_list = new ArrayList<al>();
        
        
		try {	
			
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				 al = new ArrayList<String>();
				
				 al.add(rs.getString("SELLER_ID"));
					al.add(rs.getString("NAME"));
					al.add(rs.getString("PASSWORD"));
					al.add(rs.getString("PRODUCTION"));
					
					String tk=Integer.toString(rs.getInt("TK"));
					al.add(tk);
					al.add(rs.getString("CUSTOMERNAME"));
					
					pid_list.add((al) al);
			}
			System.out.println(((ArrayList<ArrayList<String>>) pid_list).size());
			rs.close();
			ps.close();
			return (ArrayList<ArrayList<String>>) pid_list;

		} catch (SQLException e) {
			throw new RuntimeException(e);

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public Seller findBySellerId(int custId) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM SELLER WHERE SELLER_ID = ?";

		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, custId);
			Seller seller = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				seller = new Seller(
					rs.getString("NAME"),
					rs.getString("PASSWORD"),
					rs.getString("PRODUCTION"),
					rs.getInt("TK"),
					rs.getString("CUSTOMERNAME")
					
				);
			}
			rs.close();
			ps.close();
			return seller;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
		
	}

}
