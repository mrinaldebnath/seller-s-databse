package com.in28minutes.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.in28minutes.database.Seller;
import com.in28minutes.database.SellerDAO;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Controller
public class ProfileController {
	
	@Autowired
	LoginService loginservice;
	
	@RequestMapping(value="/profile",method=RequestMethod.GET)
	
	public String showprofile()
	{
		return "profile";
	}
	
	@RequestMapping(value="/profile",method=RequestMethod.POST)
	
	public String leaveprofile(HttpServletRequest request,ModelMap model)
	{
	if (request.getParameter("first") != null) {
		String name = request.getParameter("name");
		String password=request.getParameter("password");
		String production= request.getParameter("production1");
		String tk= request.getParameter("tk1");
		String customername=request.getParameter("customername1");
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
		
		Seller customer =loginservice.validateUser(name, password);
		
		if(!loginservice.isInteger(tk))
		{
			model.put("error","Sorry, cannot update to an invalid price");
		}
		
		else model.put("success","Database is updated successfully...");
		
		
		sellerDAO.update(customer,"PRODUCTION",production);
		if(loginservice.isInteger(tk))sellerDAO.update(customer,"TK",tk);
		sellerDAO.update(customer,"CUSTOMERNAME",customername);
		
		
		model.put("name", name);
		model.put("production",production);
		model.put("tk",customer.getTk());
		model.put("customername", customername);
		model.put("password", password);
		
	    return "profile";
	} else if (request.getParameter("second") != null) {
		
		String name = request.getParameter("name");
		String password=request.getParameter("password");
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
		
		Seller customer = new Seller(name,password);
		sellerDAO.delete(customer);
		
		model.put("deleted", "Deleted successfully,you do not have account anymore,\nplease sign up");
		
	    return "login";
	} else if (request.getParameter("third") != null) {
	    return "login";
	}
	 else if (request.getParameter("change") != null) {
		 
		String name = request.getParameter("name");
		String password=request.getParameter("password");
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
		
		Seller seller1 = new Seller(name,password);
		Seller seller=sellerDAO.select(seller1);
		
		model.put("name", name);
		model.put("production",seller.getProduction());
		model.put("tk",seller.getTk());
		model.put("customername", seller.getCustomername());
		model.put("password", password);
		
		return "change";
		}
	 else if (request.getParameter("show") != null)
	 {
		 String name = request.getParameter("name");
		 String password=request.getParameter("password");
			
			ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
			SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
			
			Seller seller1 = new Seller(name,password);
			Seller seller=sellerDAO.select(seller1);
			
			model.put("name", name);
			model.put("production",seller.getProduction());
			model.put("tk",seller.getTk());
			model.put("customername", seller.getCustomername());
			model.put("password", password);
			
			Connection conn;
			String url = "jdbc:mysql://localhost:3306/";
	        String dbName = "springexamples";
	        String driver = "com.mysql.jdbc.Driver";
	        String userName = "root";
	        String pass = "123456";
	 
	        try {
	            Class.forName(driver).newInstance();
	            conn = DriverManager.getConnection(url + dbName, userName, pass);
	            System.out.println("Connected!");
	 
	            ArrayList pid_list = new ArrayList();
	            
	            pid_list=sellerDAO.selectAll();
	            
	            model.put("piList", pid_list);
	            conn.close();
	            System.out.println("Disconnected!");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
			
			
			return "show";
		 
	 }
	
	return null;
	}
	

}
