package com.in28minutes.login;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.in28minutes.database.Seller;
import com.in28minutes.database.SellerDAO;

@Service
public class LoginService {
	public boolean isInteger(String s) {
	    try { 
	        Integer.parseInt(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    return true;
	}
	
	public boolean confirm(String p1, String p2)
	{
		if(p1.equals(p2))return true;
		else return false;
	}
	
	public boolean validNamePass(String n, String p)
	{
		if(n==null)return false;
		if(p==null)return false;
		return true;
	}
	
	public Seller validateUser(String user, String password) {
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
		SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
		
		Seller customer = new Seller(user.toUpperCase(),password);
		Seller logged= sellerDAO.select(customer);
		
		return logged;
	}

}