package com.in28minutes.login;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.in28minutes.database.Seller;
import com.in28minutes.database.SellerDAO;


@Controller
public class SignupController {
	
	@Autowired
	LoginService loginservice;
	
	@RequestMapping(value="/signup",method=RequestMethod.GET)
	
	public String showsignup()
	{
		return "signup";
	}
	
@RequestMapping(value="/signup",method=RequestMethod.POST)
	
	public String leavesignup(ModelMap model,HttpServletRequest request)
	{
	
		if (request.getParameter("signup") != null)
		{
			String name = request.getParameter("name");
			String password=request.getParameter("password");
			String confirm_password=request.getParameter("confirm_password");
			String production= request.getParameter("production");
			String tk= request.getParameter("tk");
			String customername=request.getParameter("customername");
			
			Seller existing=loginservice.validateUser(name, password);
			
			if(!loginservice.confirm(password, confirm_password))
			{
				model.put("error","Password did not match, try again");
				return "signup";
			}
			
			if(!loginservice.isInteger(tk))
			{
				model.put("error","Invalid price. Try again");
				return "signup";
			}
			
			if(existing!=null)
			{
				model.put("error","Username/Password combination is taken, Please choose another one");
				return "signup";
			}
			
			Seller logged=new Seller(name, password,production,Integer.parseInt(tk),customername);
			
			ApplicationContext context=new ClassPathXmlApplicationContext("Spring-Module.xml");
			SellerDAO sellerDAO = (SellerDAO) context.getBean("sellerDAO");
			
			sellerDAO.insert(logged);
			
			model.put("name", logged.getName());
			model.put("production",logged.getProduction());
			model.put("tk",logged.getTk());
			model.put("customername", logged.getCustomername());
			model.put("password", logged.getPassword());
			
			return "profile";
		}
		
		else if (request.getParameter("login") != null)
		{
			return "login";
		}
		return null;
	}
	
}
